<?php 

	include "conecta_mysql.inc";

	if (!$conexao)
		die ("Erro de conex�o com localhost, o seguinte erro ocorreu -> ".mysql_error());

	$destino = 'cad_item_ent.php';

	function get_post_action($name)
	{
	    $params = func_get_args();

	    foreach ($params as $name) {
	        if (isset($_POST[$name])) {
	            return $name;
	        }
	    }
	}


	if (IsSet($_COOKIE["cod_ent"])){
		$cod_ent = $_COOKIE["cod_ent"];
	}

	switch (get_post_action('adicionar', 'alterar', 'remover', 'encerrar')) {
	    case 'adicionar':
		    $cod_prod = $_POST ["cod_prod"];
		    $ipi = $_POST ["ipi"];
//		    echo ($ipi.'<br>');
		    $preco = $_POST ["preco"] * (1+ $ipi/100) ;
//		    echo ($preco);
		    $qtd = $_POST ["qtd"];
			$query = "INSERT INTO tb_item_compra ( id_prod, id_ent, qtd, preco) VALUES ('$cod_prod', '$cod_ent', '$qtd', '$preco')";   
	        break;

	    case 'alterar':
		    $cod_prod = $_POST ["cod_prod"];
		    $qtd = $_POST ["qtd"];
		    $preco = $_POST ["preco"];

			$query = "UPDATE tb_item_compra i
					  INNER JOIN tb_produto p
					  SET qtd = '$qtd', preco = '$preco'
					  WHERE i.id_ent = '$cod_ent'
					  AND p.cod = '$cod_prod'
					  AND p.id = i.id_prod;";
//				echo $query ."<br>";

	        break;

	    case 'remover':
		    $cod_item = $_POST ["cod_prod"];
			$query = "DELETE i
					  FROM tb_item_compra i
					  INNER JOIN tb_produto p
					  ON p.id = i.id_prod
					  WHERE p.cod = '$cod_item' AND i.id_ent = '$cod_ent';";

//				echo $query ."<br>";

	        break;

	    case 'encerrar':
			$query = "SELECT id_prod, qtd, preco from tb_item_compra where id_ent = '$cod_ent';";		
//				echo $query ."<br>";

	          $result = mysqli_query($conexao, $query);

	          while($fetch = mysqli_fetch_row($result)){
	        	$id_prod = $fetch[0];
	        	$qtd = $fetch[1];
	        	$preco = $fetch[2];
				$query = "UPDATE tb_produto
						  SET estoque = estoque + '$qtd', preco_comp = '$preco'
						  WHERE id = '$id_prod';";
				mysqli_query($conexao, $query);
//				echo $query ."<br>";

	        }

			$query = "UPDATE tb_entrada
					  SET status = 'FECHADO'
					  WHERE id = '$cod_ent';";
//			echo "<br>".$query ."<br>";


			$destino = 'main.php';
			setcookie("message", "NF entrada com sucesso!", time()+3600);
	        break;
	    default:
	        //no action sent
		}
		mysqli_query($conexao, $query);
		$conexao->close();
		header('Location: '. $destino);
?>