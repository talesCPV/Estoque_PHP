

/* SCRIPTS DE VALIDAÇÃO DE DADOS - SISTEMA FLEXIBUS*/      

      function confirma(msg) {
        return confirm(msg);
    }


    function validaCampo(obj)
    {
        for(var i = 0; i<obj.length; i++){
    
            if(obj[i].value=="")
              {
                  alert("Os campos com * são obrigatórios!");
                  return false;
              }
        }
        return false;
    }

     function estq_baixo(etq_max) {
        if (add_item.qtd.value > etq_max) {
            alert("Estoque Insuficiente !!");
            return false;
        }else{
             return true;
        }
    }


    function valida_senha(obj)
    {
        if(obj[1].value != obj[2].value)
          {
              alert("O campo \"Repita a senha\" não confere!");
              return false;
          }

        if (validaCampo(obj)){
            return true;
        }else{
            return false;
        }
    }

 
    function money(campo){
        var ok_chr = new Array('1','2','3','4','5','6','7','8','9','0');
        var text = campo.value;
        var after_dot = 0;
        var out_text = '';
        for(var i = 0; i<text.length; i++){

            if(after_dot > 0){ // conta quantas casas depois da virgula
                after_dot = after_dot + 1;
            }

            if (after_dot < 4 ){ // se não passou de 2 casas depois da virgula ( conta o ponto + 2 digitos)

                if(ok_chr.includes(text.charAt(i))){
                    out_text = out_text + text.charAt(i)

                }
                if((text.charAt(i) == ',' || text.charAt(i) == '.') && after_dot == 0){
                    out_text = out_text + '.';
                    after_dot = after_dot + 1;
                }
            }


        }
        campo.value = out_text;
    }


//JQUERY
$(document).ready(function(){

    $body = $("body");

    $(document).on({
         ajaxStart: function() { $body.addClass("loading");   },
         ajaxStop: function() { $body.removeClass("loading"); }    
    }); 

	var classe = $(this).getCookies('classe');
//    var usuario = $(this).getCookies('usuario');

//  VERIFICA SE O USUARIO TEM PERMISSÃO PARA ACESSAR A PÁGINA DE ACORDO COM O ARQUIVO /config/menu.json na sessão "seguranca"
    if (!$(this).perm(classe,'open')){
//        $.cookie('message','Você nao tem permissao para acessar esta pagina');
        $(window.document.location).attr('href',$(this).urlPath(window.location.href) + 'main.php');
    }


	$('#selTipo').change(function(){ // COMBOBOX DO CAMPO DE PESQUISA
        if($(this).val() == 'ENTRADA'){
            $('#lblDataVenc').html("Data Recebimento");
            $('#lblDest').html("Sacado");
        }else{
            $('#lblDataVenc').html("Data Vencimento");
            $('#lblDest').html("Cedente");
        }        
    }); 

    $('.checkFone').keyup(function(){
        var val= $(this).val();
        $(this).val( $(this).telefone(val));
    });

	$('.selData').change(function(){ // SELECIONA A DATA
        $('#ckbDatas').prop( "checked", true );
    });      

    $('#btnSalvar').click(function(){ 
        if ($(this).obrigatorio(['edtRef','edtDest','edtValor'])){
            if($(this).checkFinan($('#edtRef').val())){
                alert('Já existe um registro com esta referência');
            }else{
                $("#frmSaveFinan").submit();
            }
        }
    });     

    $('#btnSaveAgenda').click(function(){ 
        if ($(this).obrigatorio(['edtNome'])){
            $("#frmSaveAgenda").submit();
        }
    });     

    $("#frmSaveTinta").submit(function(event){
        if ($(this).obrigatorio(['edtDesc','edtPreco'])){
            $("#frmSaveTinta").submit();
        }else{
            event.preventDefault();
        }
     });

    $("#frmSaveProd").submit(function(event){
        if ($(this).obrigatorio(['edtDesc'])){
            $("#frmSaveProd").submit();
        }else{
            event.preventDefault();
        }
    });

    $("#frmSaveEmp").submit(function(event){
        if ($(this).obrigatorio(['edtNome'])){
            $("#frmSaveEmp").submit();
        }else{
            event.preventDefault();
        }
    });

    $('.btnNovoEmail').click(function(){ 

        var form = "<textarea class='edtTextArea' id='edtNewMail' type='text' name='edtNewMail' rows='30' cols='139'></textarea>";
        var Btn = "<table><tr><td><button id='btnEnviar'>Enviar</button></td></tr></table>";
        var head = "<table><tr><td>destinatátio:</td><td><select id='selEmail'>";

        var dados = "query=SELECT * from tb_agenda order by nome;";
        $.ajax({
            url: 'ajax/ajax.php',
            type: 'POST',
            dataType: 'html',
            data: dados,
            async: false,		
            success: function(data){
                var obj = jQuery.parseJSON( data );
                $.each(obj, function( index, value ) {
                    if(value.email){
                        head = head + '<option value="'+value.email+'">'+value.nome + ' - ' + value.email+'</option>';
                    }
                });
            }
        });

        head = head + '</select></td>';
        head = head + "</tr><tr><td>assunto:</td><td><input type='text' id='edtSubject' size='100'></td><td>"+Btn+"</td></tr></table>";

        $(".content").html(form);
        $('#popTitle').html(head);

        $(document).off('click', '#btnEnviar').on('click', '#btnEnviar', function() {
            dados = 'num=-1&body='+$('#edtNewMail').val()+'&sub='+$('#edtSubject').val()+'&dest='+$('#selEmail').val();

            $.ajax({
                url: 'ajax/ajax_sendMail.php',
                type: 'POST',
                dataType: 'html',
                data: dados,
                async: false,
                success: function(data){
                    alert('Emil enviado com sucesso');
                    $('.close').click();
                }
            });	

        });

        $(".overlay").css("visibility", "visible").css("opacity", "1");  

    });     


     // POPUP CLOSE
    $('.close').click(function(){ // BOTÃO FECHAR DO POPUP
        $(".overlay").css("visibility", "hidden").css("opacity", "0");

    }); 


    // DUPLO CLIQUE NA TEBELA tabItens
    $('#tabItens').on('dblclick','.tbl_row', function(){ // SELECIONANDO UM ÍTEM DA TABELA (DUPLO CLIQUE)

        var arr = window.location.href.split("/");
        var id = $(this).attr('id');

//        alert(arr[arr.length-1]);

        switch (arr[arr.length-1]){
        case 'pesq_ped.php#': // PÁGINA PESQ_PED (PESQUISA DE PEDIDOS)
    
            var num = $.trim($(this).children('td').slice(1, 2).text());
            var cli = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
            var data = $.trim($(this).children('td').slice(3, 4).text().toUpperCase());
            var status = $.trim($(this).children('td').slice(4, 5).text());
            var valor = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
            var table = "<table><tr><td>Cliente:</td><td>"+cli+"</td></tr><td>Data:</td><td>"+data+"</td></tr><td>Status:</td><td>"+status+"</td></tr><td>Valor:</td><td>"+valor+"</td></tr></table>";
            var form = "<form id='frmPesqPed' method='POST' action='pdf_analise.php'><input type='hidden' name='cod_ped' value='"+id+"'><input type='hidden' name='status' value='"+status+"'></form>";
            var Btn = "<br>Acesso apenas p/ consulta<br>";

            if ($(this).perm(classe,'edit')){

                Btn = "<table><tr><td><button id='btnAnalisar'>Analisar</button></td><td><button id='btnVisualizar'>Visualizar</button><button id='btnDeletar'>Deletar</button></td></tr></table>";

                $(document).off('click', '#btnAnalisar').on('click', '#btnAnalisar', function() {
                    $('#frmPesqPed').attr('action', 'pdf_analise.php');
                    $('#frmPesqPed').submit();
                });

                $(document).off('click', '#btnVisualizar').on('click', '#btnVisualizar', function() {
                    $('#frmPesqPed').attr('action', 'edita_ped.php');
                    $('#frmPesqPed').submit();
                });

                $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                    if (confirm('Deseja remover o ítem definitivamente do sistema?')) {
                        $('#frmPesqPed').attr('action', 'del_ped.php');
                        $('#frmPesqPed').submit();
                    }
                });
            }

            $(".content").html(table+form+Btn);
            $('#popTitle').html(num);

            break;
        case 'pesq_prod.php#':

            var nome = $.trim($(this).children('td').slice(1, 2).text().toUpperCase());
            var und = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
            var etq = $.trim($(this).children('td').slice(3, 4).text().toUpperCase());
            var codprod = $.trim($(this).children('td').slice(4, 5).text().toUpperCase());
            var forn = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
            var preco = $.trim($(this).children('td').slice(6, 7).text().toUpperCase());
            var table = "<table><tr><td>unidade</td><td>"+und+"</td></tr><td>Estoque</td><td>"+etq+"</td></tr><td>Cód. Fab</td><td>"+codprod+"</td></tr><td>Preço</td><td>"+preco+"</td></tr></table>";
            var form = "<form id='frmPesqProd' method='POST' action='edt_prod.php'><input type='hidden' name='cod_prod' value='"+id+"'></form>";
            var Btn = "<br>Acesso apenas p/ consulta<br>";

            if ($(this).perm(classe,'edit')){
            
                Btn = "<table><tr><td><button id='btnEditar'>Editar</button><button id='btnDeletar'>Deletar</button></td></tr></table>";

                $(document).off('click', '#btnEditar').on('click', '#btnEditar', function() {
                    $('#frmPesqProd').attr('action', 'edt_prod.php');
                    $('#frmPesqProd').submit();
                });

                $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                    if (confirm('Deseja remover o ítem definitivamente do sistema?')) {
                        $('#frmPesqProd').attr('action', 'del_prod.php');
                        $('#frmPesqProd').submit();
                    }
                });
            }

            $(".content").html(table+form+Btn);
            $('#popTitle').html(nome);

            break;

            case 'pesq_agenda.php#':  
                var id = $.trim($(this).children('td').slice(0, 1).text().toUpperCase());
                var nome = $.trim($(this).children('td').slice(1, 2).text().toUpperCase());
                var dep = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
                var email = $.trim($(this).children('td').slice(3, 4).text().toUpperCase());
                var cel = $.trim($(this).children('td').slice(4, 5).text().toUpperCase());
                var fone = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
                var emp = $.trim($(this).children('td').slice(6, 7).text().toUpperCase());
//                var table = "<table><tr><td>Nome:</td><td>"+nome+"</td></tr><tr><td>Empresa:</td><td>"+emp+"</td></tr><tr><td>Depart.:</td><td>"+dep+"</td></tr><tr><td>Email</td><td>"+email+"</td></tr><tr><td>Celular:</td><td>"+cel+"</td></tr><tr><td>Telefone:</td><td>"+fone+"</td></tr></table>";

                var form = "<form id='frmPesqAgenda' method='POST' ><input type='hidden' name='id' value='"+id+"'><input type='hidden' name='hidDel' id='hidDel' value='0'>";
                var table = "<table><tr><td>Nome</td><td> <input type='text' name='nome' maxlength='40' id='edtNome' value='"+nome.toUpperCase()+"' /></td></tr>";
                table = table  +   "<tr><td>Empresa</td><td> <input type='text' name='emp' maxlength='80' id='edtEmp' value='"+emp.toUpperCase()+"' readonly /></td></tr>";
                table = table  +   "<tr><td>Departamento</td><td> <input type='text' name='dep' maxlength='15' id='edtDep' value='"+dep.toUpperCase()+"'  /></td></tr>";
                table = table  +   "<tr><td>Email</td><td> <input type='text' name='email' maxlength='80' id='edtEmail' value='"+email.toLowerCase()+"'  /></td></tr>";
                table = table  +   "<tr><td>Cel</td><td> <input type='text' name='fone1' maxlength='15' id='edtCel' value='"+cel+"'  /></td></tr>";
                table = table  +   "<tr><td>Telefone</td><td> <input type='text' name='fone2' maxlength='15' id='edtFone' value='"+fone+"'  /></td></tr></table>";

                form = form + table + "</form>";
//                var form = "<form id='frmPesqAgenda' method='POST' action='edt_agenda.php'><input type='hidden' name='cod_prod' value='"+id+"'></form>";
                var Btn = "<br>Acesso apenas p/ consulta<br>";
    
                if ($(this).perm(classe,'edit')){
                
                    Btn = "<table><tr><td><button id='btnEditar'>Salvar</button><button id='btnDeletar'>Deletar</button></td></tr></table>";
    
                    $(document).off('click', '#btnEditar').on('click', '#btnEditar', function() {
                        $('#hidDel').val('0');
                        $('#frmPesqAgenda').attr('action', 'save_agenda.php');
                        $('#frmPesqAgenda').submit();
                    });
    
                    $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                        $('#hidDel').val('1');
                        if (confirm('Deseja remover o ítem definitivamente do sistema?')) {
                            $('#frmPesqAgenda').attr('action', 'save_agenda.php');
                            $('#frmPesqAgenda').submit();
                        }
                    });
                }
    
                $(document).off('keyup', '#edtCel').on('keyup', '#edtCel', function() {
                    var val= $(this).val();
                    $('#edtCel').val( $(this).celular(val));
                });

                $(document).off('keyup', '#edtFone').on('keyup', '#edtFone', function() {
                    var val= $(this).val();
                    $('#edtFone').val( $(this).telefone(val));
                });

                $(".content").html(form+Btn);
                $('#popTitle').html(nome);
    
                break;


            case 'email.php#':

                var id = $(this).attr('id');
                var title = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());

                dados = 'num='+id;
                var saida = ""
                $.ajax({
                    url: 'ajax/ajax_getImapBody.php',
                    type: 'POST',
                    dataType: 'html',
                    data: dados,
                    async: false,
                    success: function(data){
                        saida =data;
            
                    }
            	});	

                Btn = "<table><tr><td><button id='btnResponder'>Responder</button></td><td><button id='btnEncaminhar'>Encaminhar</button></td><td><button id='btnDeletar'>Deletar</button></td></tr></table>";


                $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                    $('#hidDel').val('1');
                    if (confirm('Deseja remover este email permanentemente do sistema?')) {
                        dados = 'num='+id;
                        $.ajax({
                            url: 'ajax/ajax_ImapDelete.php',
                            type: 'POST',
                            dataType: 'html',
                            data: dados,
                            async: false,
                            success: function(data){
                                alert(data);
                                $('.btnReceber').click();                
                            }
                        });	
    
                    }
                });

                $(document).off('click', '#btnEncaminhar').on('click', '#btnEncaminhar', function() {

                    var form = "<textarea class='edtTextArea' id='edtNewMail' type='text' name='edtNewMail' rows='30' cols='150'>"+ saida +"</textarea>";
                    var Btn = "<table><tr><td><button id='btnEnviar'>Enviar</button></td></tr></table>";
                    var head = "<table><tr><td>destinatátio:</td><td><select id='selEmail'>";
            
                    var dados = "query=SELECT * from tb_agenda order by nome;";
                    $.ajax({
                        url: 'ajax/ajax.php',
                        type: 'POST',
                        dataType: 'html',
                        data: dados,
                        async: false,		
                        success: function(data){
                            var obj = jQuery.parseJSON( data );
                            $.each(obj, function( index, value ) {
                                if(value.email){
                                    head = head + '<option value="'+value.email+'">'+value.nome + ' - ' + value.email+'</option>';
                                }
                            });
                        }
                    });
            
                    head = head + '</select></td>';
                    head = head + "</tr><tr><td>assunto:</td><td><input type='text' id='edtSubject' size='100' value=Fwd:'"+title+"'></td><td>"+Btn+"</td></tr></table>";
            
                    $(".content").html(form);
                    $('#popTitle').html(head);
                    id = -1

                });                

                $(document).off('click', '#btnResponder').on('click', '#btnResponder', function() {
                    var form = "<textarea class='edtTextArea' id='edtNewMail' type='text' name='edtNewMail' rows='30' cols='150'>"+ saida +"</textarea>";
                    Btn = "<table><tr><td><button id='btnEnviar'>Enviar</button></td></tr></table>";

                    $(".content").html(form);
                    $('#popTitle').html(title+"<br>"+Btn);

                });

                $(document).off('click', '#btnEnviar').on('click', '#btnEnviar', function() {
                    if(id < 0){
                        dados = 'num='+id + '&body='+$('#edtNewMail').val()+'&sub='+$('#edtSubject').val()+'&dest='+$('#selEmail').val();
//                        alert(dados);
                    }else{
                        dados = 'num='+id + '&body='+$('#edtNewMail').val();
                    }

                    $.ajax({
                        url: 'ajax/ajax_sendMail.php',
                        type: 'POST',
                        dataType: 'html',
                        data: dados,
                        async: false,
                        success: function(data){                           
                            alert('Email enviado com sucesso');
                            $('.close').click();
                        }
                    });	

                });

                $(".content").html(saida);
                $('#popTitle').html(title+"<br>"+Btn);

                break;



            case 'pesq_anafin.php#':

                var tipo = $.trim($(this).children('td').slice(1, 2).text().toUpperCase());
                var origem = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
                var ref = $.trim($(this).children('td').slice(3, 4).text().toUpperCase());
                var emp = $.trim($(this).children('td').slice(4, 5).text().toUpperCase());
                var venc = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
                var valor = $.trim($(this).children('td').slice(6, 7).text().toUpperCase());

                var form = "<form id='frmPesqProd' method='POST' ><input type='hidden' name='id' value='"+id+"'><input type='hidden' name='hidDel' id='hidDel' value='0'>";
                var table = "<table><tr><td>Referência / NF</td><td> <input type='text' name='ref' maxlength='30' id='edtRef' value='"+ref+"' /></td></tr>";
                var Btn = "<br>Acesso apenas p/ consulta<br><br>";

                if(tipo == 'ENTRADA'){
                    table = table +  "<tr><td>Entrada/Saida</td><td> <select name='tipo' id='selTipo'><option value='ENTRADA' selected> A Receber </option><option value='SAIDA'> A Pagar </option> </select></tr>";
                }else{
                    table = table +  "<tr><td>Entrada/Saida</td><td> <select name='tipo' id='selTipo'><option value='ENTRADA'> A Receber </option><option value='SAIDA' selected> A Pagar </option> </select></tr>";
                }
                if(origem == 'FUN'){
                    table = table +  "<tr><td>Origem</td><td> <select name='origem' id='selOrig'><option value='FUN' selected> Funilaria e Pintura </option><option value='SAN'> Sanfonados</option> option value='FUN' selected> A Receber </option><option value='OUT'> Outros </option> </select></tr>";
                }
                if(origem == 'SAN'){
                    table = table +  "<tr><td>Origem</td><td> <select name='origem' id='selOrig'><option value='FUN'> Funilaria e Pintura </option><option value='SAN' selected> Sanfonados</option> option value='FUN' selected> A Receber </option><option value='OUT'> Outros </option> </select></tr>";
                }
                if(origem == 'OUT'){
                    table = table +  "<tr><td>Origem</td><td> <select name='origem' id='selOrig'><option value='FUN'> Funilaria e Pintura </option><option value='SAN'> Sanfonados</option> option value='FUN' selected> A Receber </option><option value='OUT' selected> Outros </option> </select></tr>";
                }

                table = table + "<tr><td>Sacado / Cedente</td><td> <input type='text' name='dest' maxlength='30' id='edtDest' value='"+emp+"' /></td></tr>";
                table = table + "<tr><td>Vencimento</td><td> <input type='date' name='data_venc' maxlength='30' id='edtDataVenc' value='"+venc.split("/")[2]+'-'+venc.split("/")[1]+'-'+venc.split("/")[0]+ "' /></td></tr>";
                //da uma formatada no campo 'valor' deixando só numeros e '.'
                valor = $(this).numeros(valor).substring(0,$(this).numeros(valor).length-2) + '.' + $(this).numeros(valor).substring($(this).numeros(valor).length -2,$(this).numeros(valor).length);
                
                table = table + "<tr><td>Valor R$</td><td> <input type='text' name='valor' maxlength='15' id='edtValor' value='"+ valor +"' /></td></tr>";
                form = form + table + '</form>' ;    
                
                if ($(this).perm(classe,'edit')){

                    Btn = "<table><tr><td><button id='btnSalvar'>Salvar</button><button id='btnDeletar'>Deletar</button></td></tr></table>";

                    $(document).off('click', '#btnSalvar').on('click', '#btnSalvar', function() {
                        $('#hidDel').val('0');
                        $('#frmPesqProd').attr('action', 'save_finan.php');
                        $('#frmPesqProd').submit();
                    });
        
                    $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                        $('#hidDel').val('1');
                        if (confirm('Deseja remover este registro definitivamente do sistema?')) {
                            $('#frmPesqProd').attr('action', 'save_finan.php');
                            $('#frmPesqProd').submit();
                        }
                    });
                }

                $(document).off('keyup', '#edtValor').on('keyup', '#edtValor', function() {
                    var val= $(this).val();
                    $('#edtValor').val( $(this).moeda(val));
                });

                $(".content").html(form + Btn);
                $('#popTitle').html(id+'-'+ref+' - '+emp);
        
            break;

        case 'pesq_ent.php#':

            var nf = $.trim($(this).children('td').slice(1, 2).text().toUpperCase());
            var forn = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
            var data = $.trim($(this).children('td').slice(3, 4).text());
            var status = $.trim($(this).children('td').slice(4, 5).text().toUpperCase());
            var resp = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
            var table = "<table><tr><td>Nota Fiscal:</td><td>"+nf+"</td></tr><td>Fornecedor:</td><td>"+forn+"</td></tr><td>Data:</td><td>"+data+"</td></tr><td>Status:</td><td>"+status+"</td></tr></table>";
            var form = "<form id='frmPesqEnt' method='POST' action='edita_ent.php'><input type='hidden' name='cod_ent' value='"+id+"'><input type='hidden' name='status' value='"+status+"'></form>";
            var Btn = "<br>Acesso apenas p/ consulta<br>";

            if ($(this).perm(classe,'edit')){

                Btn = "<table><tr><td><button id='btnVisualizar'>Visualizar</button><button id='btnDeletar'>Deletar</button></td></tr></table>";

                $(document).off('click', '#btnVisualizar').on('click', '#btnVisualizar', function() {
                    $('#frmPesqEnt').attr('action', 'edita_ent.php');
                    $('#frmPesqEnt').submit();
                });

                $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                    if (confirm('Deseja remover o ítem definitivamente do sistema?')) {
                        $('#frmPesqEnt').attr('action', 'del_ent.php');
                        $('#frmPesqEnt').submit();
                    }
                });
            }

            $(".content").html(table+form+Btn);
            $('#popTitle').html(forn+' NF:'+nf);

            break;


        case 'cad_item_ped.php#': // nfe_conf.php#

            var codProd = $.trim($(this).children('td').slice(0, 1).text().toUpperCase());
            var desc = $.trim($(this).children('td').slice(1, 2).text().toUpperCase());
            var und = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
            var etq = $.trim($(this).children('td').slice(3, 4).text());
            var preco = $.trim($(this).children('td').slice(4, 5).text().toUpperCase());
            var forn = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
            var codPed = $.trim($(this).children('td').slice(6, 7).text().toUpperCase());
            var tipo = $.trim($(this).children('td').slice(7, 8).text().toUpperCase());
            var table = "<table><td>Und.:</td><td>"+und+"</td></tr><td>Preço:</td><td>"+ preco +"</td></tr><td>Forn.:</td><td>"+forn+"</td></tr></table>";
            var form = "<form id='frmAddItem' method='POST' action='add_item.php'><input type='hidden' name='preco' value='"+ $(this).moeda(preco) +"'><input type='hidden' name='op' value='add'><input type='hidden' name='cod_prod' value='"+id+"'><input type='hidden' name='und' value='"+und+"'><input type='hidden' name='cod_ped' value='"+codPed+"'><input type='hidden' name='tipo' value='"+tipo+"'>";

            var Btn = "<table><tr><td><label> Quantidade </label></td><td><input id='edtQtd' type='text' name='qtd'/></td>";
            if(tipo == 'TINTA'){
                Btn = Btn + " <td><select name='vol'><option value='0.5'>450ml</option><option selected='selected' value='1'>900ml</option><option value='2'>1.8L</option><option value='3'>2.7L</option><option value='4'>3.6L</option></select></td>";
            }else{
                Btn = Btn + "<input type='hidden' name='vol' value='1'>";
            }

            Btn = Btn + "<td><button name='adicionar' id='btnAdd'>Adicionar</button></td></tr></table></form>";

            $(document).off('click', '#btnAdd').on('click', '#btnAdd', function() {
                $('#frmAddItem').submit();
            });

            $(document).off('keyup', '#edtQtd').on('keyup', '#edtQtd', function() {
                txt = $('#edtQtd').val()
                $("#edtQtd").val($(this).numeros(txt));
            });         

            $(".content").html(table+form+Btn);
            $('#popTitle').html(desc);

            break;     
        case 'nfe_conf.php#':

            $('#selBusca').val('cod');
            $('#edtBusca').val(id);
            $('#botao_inline').trigger('click');

            break;            
        case 'cad_etq.php#':

            $('#selBusca').val('cod');
            $('#edtBusca').val(id);
            $('#botao_inline').trigger('click');

            break; 
        case 'cad_item_ent.php#':

            $('#selBusca').val('cod');
            $('#edtBusca').val(id);
            $('#botao_ok').trigger('click');

            break;             
            
        }

        $(".overlay").css("visibility", "visible").css("opacity", "1");  

    });

    $('#tabChoise').on('dblclick','.tbl_row', function(){ // SELECIONANDO UM ÍTEM DA TABELA (DUPLO CLIQUE)
        var arr = window.location.href.split("/");

        if(arr[arr.length-1] == 'cad_item_ped.php#' || arr[arr.length-1] == 'cad_item_ped.php'){ // CAD ITEM PED - TAB 1
            $('[name="cod_prod"]').val($.trim($(this).children('td').slice(0, 1).text().toUpperCase()));
            $('[name="qtd"]').val($.trim($(this).children('td').slice(3, 4).text().toUpperCase()));
            $('[name="preco"]').val($(this).moeda($.trim($(this).children('td').slice(4, 5).text().toUpperCase())));
           
            $(document).off('keyup', '#edtEdtQtd').on('keyup', '#edtEdtQtd', function() { // VALIDA OS FORMULARIOS 
                txt = $('#edtEdtQtd').val()
                $("#edtEdtQtd").val($(this).numeros(txt));
            }); 

             $(document).off('keyup', '#edtEdtPreco').on('keyup', '#edtEdtPreco', function() { // VALIDA OS FORMULÁRIOS
                txt = $('#edtEdtPreco').val()
                $("#edtEdtPreco").val($(this).moeda(txt));
            }); 
        }

        if(arr[arr.length-1] == 'cad_item_ent.php#' || arr[arr.length-1] == 'cad_item_ent.php'){ // CAD ITEM PED - TAB 1
            $('[name="cod_prod"]').val($.trim($(this).children('td').slice(0, 1).text().toUpperCase()));
            $('[name="qtd"]').val($.trim($(this).children('td').slice(3, 4).text().toUpperCase()));
            $('[name="preco"]').val($(this).moeda($.trim($(this).children('td').slice(4, 5).text().toUpperCase())));
           
            $(document).off('keyup', '#edtEdtQtd').on('keyup', '#edtEdtQtd', function() { // VALIDA OS FORMULARIOS 
                txt = $('#edtEdtQtd').val()
                $("#edtEdtQtd").val($(this).numeros(txt));
            }); 

             $(document).off('keyup', '#edtEdtPreco').on('keyup', '#edtEdtPreco', function() { // VALIDA OS FORMULÁRIOS
                txt = $('#edtEdtPreco').val()
                $("#edtEdtPreco").val($(this).moeda(txt));
            }); 
        }        

    });


});
